﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Eternal_Connections.Models;
using Microsoft.EntityFrameworkCore;



namespace Eternal_Connections.Data
{
    public class ConnectionsContext : DbContext
    {
        public ConnectionsContext(DbContextOptions<ConnectionsContext> options)
            : base(options)
        {
        }

        public DbSet<ConnectionsContext> Connections { get; set; }
    }
}