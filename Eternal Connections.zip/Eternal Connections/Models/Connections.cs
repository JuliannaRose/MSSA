﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Eternal_Connections.Models
{
    public class Connections
    {
   
    public int Id { get; set; }
    public string Name { get; set; }

    [DataType(DataType.Date)]
    public DateTime Birthday { get; set; }
    public string Religion { get; set; }
    public string Tobacco { get; set; }
    public string alcohol { get; set; }
    public string pets { get; set; }
    public decimal Income { get; set; }
    }


}
