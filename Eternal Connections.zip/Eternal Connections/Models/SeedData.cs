﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Eternal_Connections.Data;
using Eternal_Connections.Models;


namespace Eternal_Connections.Models
{
    public class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new ConnectionsContext(
                serviceProvider.GetRequiredService<
                    DbContextOptions<ConnectionsContext>>()))
            {
               
                if (context.Connections.Any())
                {
                    return;  
                }

                context.Connections.AddRange(
                    new Connections
                    {
                        Name = "John Smith",
                        Birthday = DateTime.Parse("1975-12-10"),
                        Religion = "Latter-Day-Saint",
                        Tobacco = "no",
                        alcohol = "No",
                        pets = "Cats",
                        Income = 125000

                    },

                    new Connections
                    {
                        Name = "David Young",
                        Birthday = DateTime.Parse("1982-04-05"),
                        Religion = "Latter-Day-Saint",
                        Tobacco = "no",
                        alcohol = "No",
                        pets = "dogs",
                        Income = 65000

                    },

                    new Connections
                    {
                        Name = "Eric Graham",
                        Birthday = DateTime.Parse("1984-05-25"),
                        Religion = "Latter-Day-Saint",
                        Tobacco = "no",
                        alcohol = "No",
                        pets = "None",
                        Income = 85000

                    },

                    new Connections
                    {
                        Name = "David Yates",
                        Birthday = DateTime.Parse("1979-12-25"),
                        Religion = "Latter-Day-Saint",
                        Tobacco = "no",
                        alcohol = "No",
                        pets = "dogs",
                        Income = 92000

                    }
                ) ;
                context.SaveChanges();
            }
        }
    }
}
